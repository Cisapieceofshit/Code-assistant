#ifndef __test_h
#define __test_h

#ifdef __cplusplus
extern "C"
{
#endif //

    void test();
    extern int testval[10];

#ifdef __cplusplus
}
#endif //

#endif