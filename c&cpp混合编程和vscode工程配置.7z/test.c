#include <stdio.h>
#include "test.h"

void test()
{

    printf("hello world\n");
}
int testval[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};