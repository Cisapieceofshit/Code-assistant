
#ifdef __cplusplus
extern "C"
{
#endif

    void test();
    extern int testval[10];

#ifdef __cplusplus
}
#endif
