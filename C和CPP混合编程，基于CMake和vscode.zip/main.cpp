#include <iostream>
#include <list>
#include "test.h"
using namespace std;

int main()
{
    list<int> s1;
    for (int i = 0; i < 10; i++)
    {
        s1.push_back(testval[i]);
    }
    test();
    _sleep(3000);

    return 0;
}