#include <stdio.h>
#include "test.h"

void test()
{

    printf("晏总牛逼\n");
}
int testval[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};